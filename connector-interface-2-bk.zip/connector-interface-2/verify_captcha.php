<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_response = strtolower(trim($_POST['captcha_response']));
    $correct_answer = strtolower($_SESSION['captcha_answer']);

    if ($user_response === $correct_answer) {
        //echo "CAPTCHA verified successfully!";
        header('Location: resource.php'); // Change to your main page
        exit;
    } else {
        echo "Incorrect CAPTCHA! Please try again.";
        // Optionally, you can redirect back to the CAPTCHA form
        header('Refresh: 2; url=captcha.php');
    }
}

