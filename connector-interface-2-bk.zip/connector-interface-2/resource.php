<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="robots" content="noindex, nofollow">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix Web Connector</title>
    <style>
        html,body {
            height: 100%;
            margin: 0;
            padding: 0px;
        }
        iframe {
            width: 100%;
            height: 100%; /* Adjust height as needed */
            border: none; /* Optional border styling */
        }
    </style>
</head>
<body>

<iframe src="resource-1.php" frameborder="0"></iframe>
    
</body>
</html>
