<?php
header("X-Robots-Tag: noindex, nofollow");
header('Location: captcha.php');
exit();
?>
