<?php
$mysqli = new mysqli('localhost', 'webtocon_user', 'WebtoconnecT123.', 'webtocon_db');
?>