<?php
session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['login'])) {
if (empty($_POST['accountid']) || empty($_POST['password'])) {
$error = "Account ID or Password is invalid";
}
else
{
// Define $username and $password
$accountid=$_POST['accountid'];
$password=$_POST['password'];

// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$mysqli = new mysqli('localhost', 'webtocon_user', 'WebtoconnecT123.', 'webtocon_db');

$connection = $mysqli->connect("localhost", "webtocon_user", "WebtoconnecT123.");

// To protect MySQL injection for Security purpose
$accountid = stripslashes($accountid);
$password = stripslashes($password);
$accountid = $mysqli->real_escape_string($accountid);
$password = $mysqli->real_escape_string($password);

// Selecting Database
$db = $mysqli->select_db("webtocon_db");

// SQL query to fetch information of registerd users and finds user match.
$query = $mysqli->query("SELECT * FROM `users` where BINARY `accountid` ='$accountid' AND BINARY `password`='$password'", $connection);


$rows = $query->num_rows;

if ($rows == 1) {
$_SESSION['accountid']=$accountid; // Initializing Session
header("Location: index.php"); // Redirecting To Other Page
} 
else {
$error = "Invalid ID or Password"; //Sorry your online access has been disabled, please contact your bank for further instructions
}
mysqli_close($connection); // Closing Connection
}
}


?>