<?php
session_start();

// Array of image filenames
$images = ['apple.jpeg', 'banana.jpeg', 'dog.jpeg', 'car.jpeg', 'cat.jpeg'];

// Randomly select three images
$selected_images = array_rand(array_flip($images), 3);

// Randomly choose one object as the answer
$correct_image = $selected_images[array_rand($selected_images)];
$_SESSION['captcha_answer'] = pathinfo($correct_image, PATHINFO_FILENAME); // Store the answer (the name of the image without extension)

// Display CAPTCHA form
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CAPTCHA Verification</title>
    <meta name="robots" content="noindex, nofollow">
    <style>
        img {
            width: 100px;
            margin: 5px;
            cursor: pointer;
            border: 2px solid transparent;
        }
        img.selected {
            border: 2px solid blue; /* Highlight selected image */
        }
    </style>
    <script>
        let selectedAnswer = '';

        function selectImage(answer, imgElement) {
            selectedAnswer = answer;
            document.querySelectorAll('.captcha-image').forEach(img => {
                img.classList.remove('selected'); // Remove selection from all images
            });
            imgElement.classList.add('selected'); // Highlight selected image

            // Enable the input field
            document.getElementById('captcha_response').disabled = false;
        }

        function validateForm() {
            const userInput = document.getElementById('captcha_response').value.trim().toLowerCase();
            const correctAnswer = selectedAnswer.toLowerCase();

            // Prevent submission if input does not match selected image
            if (userInput !== correctAnswer) {
                alert('Please type the name of the selected object correctly.');
                return false; // Prevent form submission
            }

            return true; // Allow form submission
        }
    </script>
</head>
<style>
    .cont{
        background: #554ab2;
        width: 30%;
        margin: 200px auto;
        padding: 30px;
        border-radius: 30px;
        text-align: center;
    }

    body{
        background: url(back.png);
        background-repeat: no-repeat;
        background-position: center center;
        background-attachment: fixed;
        background-size: cover !important;">
    }

    .cont h2{
        text-transform: uppercase;
        font-family: Manrope-Regular;
        font-size: 33px;
        color: #fff;
    }

    .cont form label{
        color: #25eca0;
        font-size: 24px;
        font-weight: bold;
    }

    .cont form input[type="text"]{
        display: block;
        margin: 20px auto;
        border-color: #fff;
        width: 60%;
        background: #fff;
        border-radius: 5px;
        padding: 10px;
        text-align: center;
    }

    .cont form input[type="submit"]{
        background-color: #fff;
        border-color: #fff;
        width: 40%;
        height: 40px;
        box-shadow: none;
        text-transform: uppercase;
        color: #404040;
    }
</style>
<body>
<div class="cont">
<h2>VERIFICATION</h2>
<p>Select and enter the name of the object: <strong><?php echo ucfirst($_SESSION['captcha_answer']); ?></strong></p>

<form action="verify_captcha.php" method="POST" onsubmit="return validateForm()">
    <div>
        <?php foreach ($selected_images as $image): ?>
            <img src="captcha_images/<?php echo $image; ?>" 
                 alt="CAPTCHA Image" 
                 class="captcha-image" 
                 onclick="selectImage('<?php echo pathinfo($image, PATHINFO_FILENAME); ?>', this)">
        <?php endforeach; ?>
    </div>
    <input type="text" id="captcha_response" name="captcha_response" required placeholder="Enter the name of the object" disabled>
    <input type="submit" value="Submit">
</form>
        </div>
</body>
</html>
