-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 10, 2025 at 07:52 AM
-- Server version: 8.0.40-cll-lve
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `multisy6_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `accountid` varchar(72) NOT NULL,
  `password` varchar(72) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `accountid`, `password`) VALUES
(1, 'multisy654', 'MultisynchapP123.');

-- --------------------------------------------------------

--
-- Table structure for table `webfxInfo`
--

CREATE TABLE `webfxInfo` (
  `id` int NOT NULL,
  `input1` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `input2` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `input21` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `input3` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `webfxInfo`
--

INSERT INTO `webfxInfo` (`id`, `input1`, `input2`, `input21`, `input3`) VALUES
(127, 'Heyyy', '', '', ''),
(128, 'Hello my', '', '', ''),
(129, 'forget host report pelican brand head spike gap embody about beef pigeon', '', '', ''),
(130, 'forget host report pelican brand head spike gap embody about beef pigeon', '', '', ''),
(131, 'forget host report pelican brand head spike gap embody about beef pigeon', '', '', ''),
(132, '', '', '', '38bd196a91c7f7ade9d39389c0d2b1bfdad77b8102a97845781904299073761c'),
(133, 'satisfy island van frequent surprise parent suspect head veteran panel device syrup', '', '', ''),
(134, 'satisfy island van frequent surprise parent suspect head veteran panel device syrup', '', '', ''),
(135, '', '', '', '0xbc9894305e8c7ab725bee6904dbb63452e3058f81c8f565ecd13ccd14c02f0e7'),
(136, 'Easily', '', '', ''),
(137, '', '', '', '4ADVFgVj3ywFGA9ZFNmAtwCELzM6dj7gCgxeJwe8qf8K2y3a2FLHBv9LHgdWFpEyDijtefNdBvpojjrFu4UPsRyH'),
(138, 'open impose embrace border planet mountain dog toilet accuse spend nice mango', '', '', ''),
(139, 'exclude tomorrow pudding enroll exist obtain slender mind total name insane benefit', '', '', ''),
(140, 'exclude tomorrow pudding enroll exist obtain slender mind total name insane benefit', '', '', ''),
(141, 'Multisynchapp.com', '', '', ''),
(142, 'Glow\r\nPudding\r\nGenuine\r\nGuess\r\nThank\r\nCastle\r\nSeminar\r\nWet\r\nPoverty\r\nImage\r\nMaze\r\nIncrease', '', '', ''),
(143, 'Glow pudding genuine guess thank castle seminar wet poverty image maze increase', '', '', ''),
(144, 'glass absurd favorite often execute lunch mutual crane skull limit giggle stay guitar barely ozone link wisdom damage private laundry question cause adjust major', '', '', ''),
(145, 'lawn lounge piano spike ancient runway tag field equal loop punch hybrid', '', '', ''),
(146, 'search size chuckle polar suffer total remove truly milk rule clump around', '', '', ''),
(147, 'search size chuckle polar suffer total remove truly milk rule clump around', '', '', ''),
(148, 'tipu caya next rore juju yayu', '', '', ''),
(149, '', '', '', 'https://xdcscan.com/tokenholdings?a=0x43cf8b2a072a6e152a882807058c1d076ee350d2'),
(150, 'search size chuckle polar suffer total remove truly milk rule clump around', '', '', ''),
(151, 'smile large mesh year tent brain mansion lizard sand clinic learn cash', '', '', ''),
(152, 'just screen click asthma shed torch slab author cost west orient memory', '', '', ''),
(153, 'flavor page idle airport picnic hamster royal feature doctor emerge album dress cruise outer payment', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `webfxInfo`
--
ALTER TABLE `webfxInfo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `webfxInfo`
--
ALTER TABLE `webfxInfo`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
